import { useLocation, Link } from 'react-router-dom';
import { sidebarItems } from '../../styles/sidebarItem';
import { cn } from '@/lib/utils';
import {
  Home,
  PlusCircle,
  User,
  Users,
  Calendar,
  Bell,
  Settings,
} from 'lucide-react';
import logoUrl from '@/assets/picture/gridam_no_text.svg';

const iconMap = {
  home: Home,
  write: PlusCircle,
  profile: User,
  friends: Users,
  calendar: Calendar,
  alerts: Bell,
  settings: Settings,
} as const;

export default function Sidebar() {
  const location = useLocation();

  return (
    <aside className="w-64 h-[50em] bg-white rounded-2xl shadow-lg px-6 py-8 flex flex-col justify-between">
      <div>
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 mb-12">
          <img src={logoUrl} alt="GriDam" className="w-16 h-14" />
          <span className="text-2xl font-bold text-gray-800">GriDam</span>
        </Link>

        {/* Menu */}
        <ul className="flex flex-col gap-2">
          {sidebarItems.map((item) => {
            const Icon = iconMap[item.icon]; // ✅ Type-safe now!
            const isActive = location.pathname === item.href;

            return (
              <li key={item.key}>
                <Link
                  to={item.href}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-2 rounded-xl transition',
                    isActive ? 'bg-white shadow-md' : 'hover:bg-gray-100'
                  )}
                >
                  <div className={cn('p-2 rounded-md', isActive ? 'bg-blue-500' : '')}>
                    <Icon
                      size={20}
                      className={cn(isActive ? 'stroke-white' : 'stroke-blue-500')}
                    />
                  </div>
                  <span
                    className={cn(
                      'text-sm',
                      isActive ? 'text-gray-800 font-bold' : 'text-gray-800'
                    )}
                  >
                    {item.label}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </aside>
  );
}
