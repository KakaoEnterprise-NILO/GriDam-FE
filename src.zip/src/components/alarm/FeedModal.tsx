"use client"
//해당 파일은 나중에 feed컴포넌트 완성되면 공용 feed컴포넌트로 대체할 예정정

import { useState } from "react"
import { X, Heart, Share, Bookmark, Send } from "lucide-react"
import { Button } from "@/components/ui/button"

interface FeedModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function FeedModal({ isOpen, onClose }: FeedModalProps) {
  const [comment, setComment] = useState("")
  const [isLiked, setIsLiked] = useState(false)
  const [isBookmarked, setIsBookmarked] = useState(false)

  if (!isOpen) return null

  const handleSubmitComment = () => {
    if (comment.trim()) {
      // 여기서 댓글 추가 로직 구현
      console.log("댓글 추가:", comment)
      setComment("")
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* 헤더 */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-3">
            <img
              src="/placeholder.svg?height=40&width=40"
              alt="Life_is_good"
              className="w-10 h-10 rounded-full object-cover"
            />
            <div>
              <h3 className="font-semibold text-gray-900">Life_is_good</h3>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="text-blue-600 border-blue-600 hover:bg-blue-50">
              팔로우
            </Button>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* 피드 이미지 */}
        <div className="relative">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-vFqyad3oiJPz1L580jbqy1HGjybmFN.png"
            alt="피드 이미지"
            className="w-full h-64 object-cover"
          />
        </div>

        {/* 액션 버튼들 */}
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsLiked(!isLiked)}
              className={`transition-colors ${isLiked ? "text-red-500" : "text-gray-600 hover:text-red-500"}`}
            >
              <Heart className={`w-6 h-6 ${isLiked ? "fill-current" : ""}`} />
            </button>
            <button className="text-gray-600 hover:text-gray-800 transition-colors">
              <Share className="w-6 h-6" />
            </button>
          </div>
          <button
            onClick={() => setIsBookmarked(!isBookmarked)}
            className={`transition-colors ${isBookmarked ? "text-blue-600" : "text-gray-600 hover:text-blue-600"}`}
          >
            <Bookmark className={`w-6 h-6 ${isBookmarked ? "fill-current" : ""}`} />
          </button>
        </div>

        {/* 피드 내용 */}
        <div className="px-4 pb-4">
          <p className="text-gray-800 mb-3">오늘 좋은 하루~^^ 하늘 보며 힐링하세요</p>
          <div className="flex gap-2 mb-4">
            <span className="text-blue-600 font-medium">#기쁨</span>
            <span className="text-blue-600 font-medium">#평화</span>
          </div>
        </div>

        {/* 댓글 섹션 */}
        <div className="border-t">
          <div className="p-4">
            <div className="flex items-start gap-3 mb-4">
              <img
                src="/placeholder.svg?height=32&width=32"
                alt="user_user"
                className="w-8 h-8 rounded-full object-cover"
              />
              <div>
                <span className="font-semibold text-sm">user_user</span>
                <p className="text-gray-800 text-sm">커피는 아메리카노</p>
              </div>
            </div>
          </div>

          {/* 댓글 입력 */}
          <div className="border-t p-4">
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="댓글 추가..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                onKeyPress={(e) => e.key === "Enter" && handleSubmitComment()}
              />
              <Button onClick={handleSubmitComment} disabled={!comment.trim()} size="sm" className="px-3">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
