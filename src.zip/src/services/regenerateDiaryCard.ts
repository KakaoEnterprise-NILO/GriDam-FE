// src/services/regenerateDiaryCard.ts
import axios from "axios";

export async function regenerateDiaryCard({
  diaryId,
  title,
  content,
  imageFile,
  token,
}: {
  diaryId: string;
  title: string;
  content: string;
  imageFile?: File | null;
  token: string;
}) {
  const formData = new FormData();

  formData.append(
    "request",
    new Blob([JSON.stringify({ title, content })], { type: "application/json" })
  );

  if (imageFile) {
    formData.append("image", imageFile);
  }

  const res = await axios.patch(`/api/diary`, formData, {
    params: { diaryId },
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "multipart/form-data",
    },
  });

  return res.data.result;
}
